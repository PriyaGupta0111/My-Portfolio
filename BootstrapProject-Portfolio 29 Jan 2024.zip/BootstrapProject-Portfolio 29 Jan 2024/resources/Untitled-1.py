# s= "this"
# s2= "string2"
# print(s.join(s2))
list_1 = ['Hello', '123', '!', 'This', 'is', 'Python'] 
lis2= ['3','3','5']
list_1.__delitem__(0)
# print(len(lis2))

# separator = '_' 
# separator2= "0"

# result = separator.join(list_1)+separator2.join(list_1)

# print(result)
a=[1,2,45,6]
# if 2 in a:
#     print("yes")
# else:
#     print("no")
l1=[]
t= int(input("entery for how many classes"))
for i in range(t):
    v= input(f"enter the name  of {i+1} student")
    print(v)

